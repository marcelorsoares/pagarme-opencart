<?php
$_['text_wait']         = 'Por favor, aguarde!';
$_['button_confirm'] = 'Gerar boleto';
?>